from datetime import date
import dash
from dash_bootstrap_components._components.CardGroup import CardGroup
from dash_html_components.Footer import Footer

import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output
from pandas.core.base import IndexOpsMixin
from pandas.io.formats import style
import plotly.express as px
import pandas as pd
import plotly.graph_objects as go
import components as comp
import data_access as da
import dash_table


css_link = "/assets/default_style.css"
external_stylesheets = [css_link]

application = dash.Dash(
    __name__, external_stylesheets=external_stylesheets, suppress_callback_exceptions=True)
server = application.server

exercise_database = []

application.layout = html.Div(
    html.Div(
        [
            html.Div(
                [
                    html.Div(
                        children=comp.player_name(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.date_picker(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.initial_exercise_check(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=html.Div(
                            children=comp.exercise_dropdown(None),
                            id="exercise-dropdown-div",
                        ),
                        style={
                            "display": "inline-block",
                            "width": "30%",
                        },
                    ),
                ]
            ),
            html.Div(
                [
                    html.Div(
                        children=comp.block_count(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.set_count(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.rep_count(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.time_input_text_area(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                ]
            )
            ,
            html.Div(
                [
                    html.Div(
                        children=comp.weight_input_text_area(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.tempo_input_text_area(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.strength_goal_dropdown(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.notes_text_area(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                ]
            )
            ,
            html.Div(
                [
                    html.Div(
                        children=comp.contraction_type_dropdown(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.include_type_dropdown(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.contraction_speed_dropdown(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                    html.Div(
                        children=comp.time_dropdown_(),
                        style={
                            "display": "inline-block",
                            "width": "20%",
                        },
                    ),
                ]
            ),
            html.Div(
                html.Button("Submit", id="submit-val", n_clicks=0), id="button-div"
            ),
            html.Div(children=[comp.blank_dashtable()], id="dashtable-area"),
        ]
    ),
)


@application.callback(
    [Output(component_id="exercise-dropdown-div", component_property="children")],
    [Input(component_id="exercise-dose-dropdown", component_property="value")]
)

def update_exercise(exercise_groups):
    return [comp.exercise_dropdown(exercise_groups)]

@application.callback(
    [
        Output(component_id="dashtable-area", component_property='children'),
        Output(component_id="button-div", component_property="children")
    ],
    [
        Input(component_id="submit-val", component_property='n_clicks'),
        Input(component_id="player-name-dropdown", component_property='value'),
        Input(component_id="date-picker", component_property="date"),
        Input(component_id="block-dropdown", component_property='value'),
        Input(component_id="exercise-dropdown", component_property='value'),
        Input(component_id="set-dropdown", component_property="value"),
        Input(component_id="rep-dropdown", component_property='value'),
        Input(component_id="time-input-dropdown", component_property="value"),
        Input(component_id="weight-dropdown", component_property='value'),
        Input(component_id="tempo-dropdown", component_property="value"),
        Input(component_id="strength-dropdown", component_property='value'),
        Input(component_id="notes-area", component_property="value"),

        Input(component_id="contraction-types-dropdown",
              component_property="value"),
        Input(component_id="include-types-dropdown",
              component_property='value'),
        Input(component_id="contraction-speed-dropdown",
              component_property="value"),
        Input(component_id="time-of-day-dropdown", component_property="value"),
        Input(component_id="table", component_property='data'),
    ],
)
def update_date_based_metrics(submit_val, 
                              player_name, 
                              date_picker, 
                              block, 
                              exercise,
                              set, 
                              rep, 
                              time, 
                              weight, 
                              tempo, 
                              strength, 
                              notes, 
                              contraction_types,
                              include,
                              contraction_speed,
                              time_of_day,
                              table_data,
                              ):
    
    button = html.Button('Submit', id='submit-val', n_clicks=1)
    table_data = pd.DataFrame(table_data)

    if submit_val == 1:
        data = table_data 
        table = dash_table.DataTable(
                id='table',
                columns=[{"name": i, "id": i} for i in data.columns],
                data=data.to_dict('records'))
        return [table, button]
    else:
        records = {"player_name":[player_name], 
                    "date_picker":[date_picker], 
                    "block":[block], 
                    "exercise":[exercise],
                    "set":[set], 
                    "rep":[rep],
                    "time":[time],
                    "weight":[weight],
                    "tempo":[tempo], 
                    "strength":[strength],
                    "notes":[notes], 
                    "contraction_types":[contraction_types],
                    "time_of_day":[time_of_day]
        }
        data = pd.DataFrame(records)
        data = pd.concat([table_data, data], axis=0)
        table = dash_table.DataTable(
                id='table',
                columns=[{"name": i, "id": i} for i in data.columns],
                data=data.to_dict('records'),
                editable=True,
                )
        data.to_clipboard(excel=True)
        return [table, button]


if __name__ == "__main__":
    application.run_server(debug=True, port=8080)
