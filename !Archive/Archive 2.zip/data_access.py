import gspread
import pandas as pd
import numpy as np


def calendar_schedule():
    gc = gspread.service_account(filename="credentials.json")

    sh = gc.open_by_key('10SdQhvm7ndVYgmZkSqvCm-VCzCNu0yM7sRgrst8nWKc') # Calendar Schedule Database

    dataframe = pd.DataFrame(sh.sheet1.get_all_records())
    dataframe = dataframe.replace('', np.nan)


    return dataframe

def exercise_database():
    gc = gspread.service_account(filename="credentials.json")

    sh = gc.open_by_key('1iPEXaR9HXw817QJ_RNzZEE7qCtOKjVfJ-vPuiU-RpHI') # Calendar Schedule Database

    dataframe = pd.DataFrame(sh.worksheet("ExerciseDatabaseLive").get_all_records())
    dataframe = dataframe.replace('', np.nan)

    return dataframe

def daily_workout_card():
    gc = gspread.service_account(filename="credentials.json")

    sh = gc.open_by_key('1iPEXaR9HXw817QJ_RNzZEE7qCtOKjVfJ-vPuiU-RpHI') # Calendar Schedule Database

    dataframe = pd.DataFrame(sh.worksheet("DailyWorkoutCardLive").get_all_records())
    dataframe = dataframe.replace('', np.nan)

    return dataframe

def overall_calendar_database():
    gc = gspread.service_account(filename="credentials.json")

    sh = gc.open_by_key('10SdQhvm7ndVYgmZkSqvCm-VCzCNu0yM7sRgrst8nWKc')

    dataframe_import = pd.DataFrame(sh.worksheet("Total Activity").get_all_records())
    dataframe = dataframe_import.replace('', np.nan)

    return dataframe

def data_options():
    gc = gspread.service_account(filename="credentials.json")

    sh = gc.open_by_key('1iPEXaR9HXw817QJ_RNzZEE7qCtOKjVfJ-vPuiU-RpHI')

    dataframe_import = pd.DataFrame(sh.worksheet("ListsLive").get_all_records())
    dataframe = dataframe_import.replace('', np.nan)

    return dataframe